package com.juliusinc;

import java.util.Locale;

/**
 * Passiver Markt-Feed: merkt sich Chat-Zeilen, die du selbst als Stichwort festlegst.
 * Liest nur Nachrichten, die dein Client ohnehin empfaengt. Es werden keine Pakete gesendet.
 */
public final class Feed {
    private static String last = "";

    private Feed() {}

    public static void add(String raw) {
        if (!Data.root.feedEnabled || raw == null) return;
        String line = raw.trim();
        if (line.isEmpty() || line.equals(last)) return;
        String low = line.toLowerCase(Locale.ROOT);
        boolean match = false;
        for (String k : Data.root.keywords.toLowerCase(Locale.ROOT).split(",")) {
            k = k.trim();
            if (!k.isEmpty() && low.contains(k)) {
                match = true;
                break;
            }
        }
        if (!match) return;
        last = line;
        Data.root.feed.add(Fmt.time(System.currentTimeMillis()) + "  " + line);
        while (Data.root.feed.size() > 200) Data.root.feed.remove(0);
        Data.dirty = true;
    }
}
