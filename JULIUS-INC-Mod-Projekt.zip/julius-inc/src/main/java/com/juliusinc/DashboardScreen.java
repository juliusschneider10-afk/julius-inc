package com.juliusinc;

import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.function.Consumer;

import net.fabricmc.loader.api.FabricLoader;
import net.minecraft.ChatFormatting;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.components.Renderable;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.player.Inventory;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;

/** JULIUS INC. - THE HUGO TRADING COMPANY: Dashboard in Dunkelgruen, Gold und Schwarz. */
public class DashboardScreen extends Screen {
    private static final int C_BG = 0xFF070A08;
    private static final int C_PANEL = 0xFF0C2A1A;
    private static final int C_PANEL2 = 0xFF103221;
    private static final int C_GOLD = 0xFFD4AF37;
    private static final int C_GOLD_L = 0xFFF3D77A;
    private static final int C_TEXT = 0xFFEAEAEA;
    private static final int C_MUTED = 0xFF93B0A0;
    private static final int C_GOOD = 0xFF5BE08A;
    private static final int C_BAD = 0xFFFF6B6B;

    private enum Tab {
        OVERVIEW("Übersicht"), TRADE("Handel"), HISTORY("Verlauf"), STOCK("Bestand"),
        PRICES("Preise"), FEED("Feed"), SETTINGS("Optionen");

        final String label;

        Tab(String label) {
            this.label = label;
        }
    }

    private static Tab tab = Tab.OVERVIEW;
    private static String fItem = "Spawner", fQty = "1", fPrice = "", fNote = "";
    private static String pItem = "", pBuy = "", pSell = "";
    private static String capIn = "";

    private Calc.Stats st;
    private String status = "";
    private int statusColor = C_MUTED;
    private int page = 0;
    private long pendingDelete = -1;
    private String pendingPrice = null;
    private boolean confirmWipe = false;
    private int px, py, pw, ph, cy;

    public DashboardScreen() {
        super(Component.literal("JULIUS INC."));
    }

    // ------------------------------------------------------------------ Aufbau

    @Override
    protected void init() {
        pw = Math.min(this.width - 16, 480);
        ph = Math.min(this.height - 16, 290);
        px = (this.width - pw) / 2;
        py = (this.height - ph) / 2;
        cy = py + 56;
        st = Calc.compute();

        Renderable canvas = (g, mx, my, d) -> {
            drawFrame(g);
            drawContent(g);
        };
        this.addRenderableOnly(canvas);

        Tab[] tabs = Tab.values();
        int tw = (pw - 12) / tabs.length;
        for (int i = 0; i < tabs.length; i++) {
            final Tab t = tabs[i];
            Button b = Button.builder(Component.literal(t.label), btn -> switchTab(t))
                    .bounds(px + 6 + i * tw, py + 30, tw - 2, 20).build();
            b.active = (t != tab);
            this.addRenderableWidget(b);
        }

        switch (tab) {
            case OVERVIEW -> { }
            case TRADE -> buildTrade();
            case HISTORY -> buildHistory();
            case STOCK -> pager(holdingsSorted().size(), per(13, 52));
            case PRICES -> buildPrices();
            case FEED -> buildFeed();
            case SETTINGS -> buildSettings();
        }
    }

    private void switchTab(Tab t) {
        tab = t;
        page = 0;
        status = "";
        pendingDelete = -1;
        pendingPrice = null;
        confirmWipe = false;
        this.rebuildWidgets();
    }

    private void setStatus(String s, int color) {
        status = s;
        statusColor = color;
    }

    private int per(int rowH, int reserved) {
        return Math.max(2, (ph - 56 - reserved) / rowH);
    }

    private EditBox box(int x, int y, int w, String value, String hint, Consumer<String> setter) {
        EditBox e = new EditBox(this.font, x, y, w, 20, Component.literal(hint));
        e.setMaxLength(80);
        e.setValue(value);
        e.setHint(Component.literal(hint));
        e.setResponder(setter);
        this.addRenderableWidget(e);
        return e;
    }

    private Button btn(int x, int y, int w, String label, Runnable action) {
        Button b = Button.builder(Component.literal(label), x0 -> action.run()).bounds(x, y, w, 20).build();
        this.addRenderableWidget(b);
        return b;
    }

    private void pager(int total, int perPage) {
        int pages = Math.max(1, (total + perPage - 1) / perPage);
        if (page >= pages) page = pages - 1;
        if (page < 0) page = 0;
        int y = py + ph - 34;
        Button prev = btn(px + pw - 110, y, 20, "<", () -> {
            page--;
            this.rebuildWidgets();
        });
        Button next = btn(px + pw - 30, y, 20, ">", () -> {
            page++;
            this.rebuildWidgets();
        });
        prev.active = page > 0;
        next.active = page < pages - 1;
    }

    private void pageLabel(GuiGraphicsExtractor g, int total, int perPage) {
        int pages = Math.max(1, (total + perPage - 1) / perPage);
        txt(g, (page + 1) + " / " + pages, px + pw - 86, py + ph - 28, C_MUTED);
    }

    // ------------------------------------------------------------------ Handel

    private void buildTrade() {
        int bx = px + 96, bw = pw - 106;
        box(bx, cy, bw, fItem, "z.B. Skeleton Spawner", s -> fItem = s);
        box(bx, cy + 24, 120, fQty, "Menge", s -> fQty = s);
        int pbw = Math.max(70, bw - 160);
        box(bx, cy + 48, pbw, fPrice, "Stückpreis, z.B. 250k", s -> fPrice = s);
        btn(bx + pbw + 4, cy + 48, 76, "Kaufkurs", () -> fillFromMarket(true));
        btn(bx + pbw + 84, cy + 48, 76, "Verkaufskurs", () -> fillFromMarket(false));
        box(bx, cy + 72, bw, fNote, "Notiz (optional)", s -> fNote = s);

        int aw = (pw - 20 - 12) / 4;
        int ay = cy + 100;
        btn(px + 10, ay, aw, "Kauf buchen", () -> book(Data.Type.BUY));
        btn(px + 10 + (aw + 4), ay, aw, "Verkauf buchen", () -> book(Data.Type.SELL));
        btn(px + 10 + 2 * (aw + 4), ay, aw, "Ausgabe", () -> book(Data.Type.EXPENSE));
        btn(px + 10 + 3 * (aw + 4), ay, aw, "Einnahme", () -> book(Data.Type.INCOME));
    }

    private void fillFromMarket(boolean buy) {
        Data.Price p = Data.price(fItem);
        double v = p == null ? 0 : (buy ? p.buy : p.sell);
        if (v <= 0) {
            setStatus("Kein " + (buy ? "Kauf" : "Verkaufs") + "preis für diesen Artikel im Tab Preise hinterlegt.", C_BAD);
        } else {
            fPrice = Fmt.plain(v);
            setStatus("Preis aus der Preisliste übernommen.", C_GOOD);
        }
        this.rebuildWidgets();
    }

    private void book(Data.Type type) {
        String item = fItem.trim();
        boolean goods = type == Data.Type.BUY || type == Data.Type.SELL;
        if (goods && item.isEmpty()) {
            setStatus("Bitte einen Artikel eingeben.", C_BAD);
            return;
        }
        long qty = Fmt.parseQty(fQty);
        if (qty < 1) {
            setStatus("Ungültige Menge (ganze Zahl ab 1).", C_BAD);
            return;
        }
        double price = Fmt.parse(fPrice);
        if (Double.isNaN(price) || price < 0) {
            setStatus("Ungültiger Preis. Beispiele: 1500, 1,5k, 2m", C_BAD);
            return;
        }
        if (item.isEmpty()) item = type == Data.Type.EXPENSE ? "Ausgabe" : "Einnahme";

        String warn = "";
        double total = qty * price;
        if (type == Data.Type.SELL) {
            Calc.Holding h = st.holdings.get(Calc.key(item));
            if (h == null || h.qty < qty) warn = " Achtung: mehr verkauft als im Bestand erfasst.";
        } else if (type == Data.Type.BUY || type == Data.Type.EXPENSE) {
            if (total > st.cash) warn = " Achtung: Kasse wird negativ.";
        }

        Data.Tx t = new Data.Tx();
        t.id = Data.nextId();
        t.time = System.currentTimeMillis();
        t.type = type;
        t.item = item;
        t.qty = qty;
        t.price = price;
        t.note = fNote.trim();
        Data.root.tx.add(t);
        Data.save();
        fNote = "";
        setStatus(label(type) + " gebucht: " + qty + " x " + item + " = " + Fmt.money(total) + "." + warn,
                warn.isEmpty() ? C_GOOD : C_GOLD_L);
        this.rebuildWidgets();
    }

    // ------------------------------------------------------------------ Verlauf

    private List<Data.Tx> historyList() {
        List<Data.Tx> l = new ArrayList<>(Data.root.tx);
        l.sort(Comparator.comparingLong((Data.Tx t) -> t.time).thenComparingLong(t -> t.id));
        Collections.reverse(l);
        return l;
    }

    private void buildHistory() {
        List<Data.Tx> list = historyList();
        int per = per(22, 38);
        pager(list.size(), per);
        int from = page * per, to = Math.min(list.size(), from + per);
        for (int i = from; i < to; i++) {
            final long id = list.get(i).id;
            int y = cy + (i - from) * 22;
            btn(px + pw - 34, y, 20, pendingDelete == id ? "!" : "x", () -> {
                if (pendingDelete == id) {
                    Data.root.tx.removeIf(x -> x.id == id);
                    Data.save();
                    pendingDelete = -1;
                    setStatus("Buchung gelöscht.", C_GOLD_L);
                } else {
                    pendingDelete = id;
                    setStatus("Nochmal klicken (!), um die Buchung endgültig zu löschen.", C_GOLD_L);
                }
                this.rebuildWidgets();
            });
        }
    }

    // ------------------------------------------------------------------ Preise

    private void buildPrices() {
        int avail = pw - 20 - 70 - 12;
        int wItem = (int) (avail * 0.4), wBuy = (int) (avail * 0.3), wSell = avail - wItem - wBuy;
        int x = px + 10;
        box(x, cy, wItem, pItem, "Artikel", s -> pItem = s);
        box(x + wItem + 4, cy, wBuy, pBuy, "Kauf-Preis", s -> pBuy = s);
        box(x + wItem + wBuy + 8, cy, wSell, pSell, "Verkaufs-Preis", s -> pSell = s);
        btn(px + pw - 80, cy, 70, "Speichern", this::savePrice);

        int per = per(22, 78);
        int total = Data.root.prices.size();
        pager(total, per);
        int from = page * per, to = Math.min(total, from + per);
        for (int i = from; i < to; i++) {
            final Data.Price p = Data.root.prices.get(i);
            int y = cy + 40 + (i - from) * 22;
            btn(px + pw - 34, y, 20, p.item.equals(pendingPrice) ? "!" : "x", () -> {
                if (p.item.equals(pendingPrice)) {
                    Data.root.prices.remove(p);
                    Data.save();
                    pendingPrice = null;
                    setStatus("Preis gelöscht.", C_GOLD_L);
                } else {
                    pendingPrice = p.item;
                    setStatus("Nochmal klicken (!), um den Preis zu löschen.", C_GOLD_L);
                }
                this.rebuildWidgets();
            });
        }
    }

    private void savePrice() {
        String item = pItem.trim();
        if (item.isEmpty()) {
            setStatus("Bitte einen Artikel eingeben.", C_BAD);
            return;
        }
        double buy = pBuy.trim().isEmpty() ? 0 : Fmt.parse(pBuy);
        double sell = pSell.trim().isEmpty() ? 0 : Fmt.parse(pSell);
        if (Double.isNaN(buy) || Double.isNaN(sell) || buy < 0 || sell < 0 || (buy == 0 && sell == 0)) {
            setStatus("Mindestens ein gültiger Preis nötig (z.B. 250k).", C_BAD);
            return;
        }
        Data.Price p = Data.price(item);
        if (p == null) {
            p = new Data.Price();
            p.item = item;
            Data.root.prices.add(p);
        }
        p.buy = buy;
        p.sell = sell;
        p.time = System.currentTimeMillis();
        Data.save();
        setStatus("Preis für " + item + " gespeichert.", C_GOOD);
        this.rebuildWidgets();
    }

    // ------------------------------------------------------------------ Feed

    private void buildFeed() {
        int per = per(11, 52);
        pager(Data.root.feed.size(), per);
        btn(px + 10, py + ph - 34, 100, "Feed leeren", () -> {
            Data.root.feed.clear();
            Data.save();
            setStatus("Feed geleert.", C_GOLD_L);
            this.rebuildWidgets();
        });
    }

    // ------------------------------------------------------------------ Optionen

    private void buildSettings() {
        if (capIn.isEmpty()) capIn = Fmt.plain(Data.root.startCapital);
        box(px + 170, cy, 120, capIn, "Startkapital", s -> capIn = s);
        btn(px + 296, cy, 70, "Setzen", () -> {
            double v = Fmt.parse(capIn);
            if (Double.isNaN(v) || v < 0) {
                setStatus("Ungültiges Startkapital.", C_BAD);
            } else {
                Data.root.startCapital = v;
                Data.save();
                setStatus("Startkapital gesetzt: " + Fmt.money(v), C_GOOD);
            }
            this.rebuildWidgets();
        });
        box(px + 170, cy + 28, pw - 180, Data.root.keywords, "Stichwörter, mit Komma getrennt", s -> {
            Data.root.keywords = s;
            Data.dirty = true;
        });
        btn(px + 10, cy + 56, 150, "Feed: " + (Data.root.feedEnabled ? "AN" : "AUS"), () -> {
            Data.root.feedEnabled = !Data.root.feedEnabled;
            Data.save();
            this.rebuildWidgets();
        });
        btn(px + 10, cy + 84, 150, "CSV exportieren", this::exportCsv);
        btn(px + 10, cy + 112, 150, confirmWipe ? "SICHER? Nochmal klicken" : "Alle Daten löschen", () -> {
            if (confirmWipe) {
                Data.root = new Data.Root();
                Data.save();
                confirmWipe = false;
                capIn = "";
                setStatus("Alle Daten gelöscht.", C_GOLD_L);
            } else {
                confirmWipe = true;
                setStatus("Das löscht ALLES (Buchungen, Preise, Startkapital). Nochmal klicken zum Bestätigen.", C_BAD);
            }
            this.rebuildWidgets();
        });
    }

    private void exportCsv() {
        try {
            Path f = FabricLoader.getInstance().getConfigDir().resolve("julius_inc_export.csv");
            StringBuilder sb = new StringBuilder("\uFEFFDatum;Typ;Artikel;Menge;Stueckpreis;Gesamt;Gewinn;Notiz\n");
            List<Data.Tx> l = new ArrayList<>(Data.root.tx);
            l.sort(Comparator.comparingLong((Data.Tx t) -> t.time));
            for (Data.Tx t : l) {
                Double p = st.profitByTx.get(t.id);
                sb.append(Fmt.date(t.time)).append(';').append(label(t.type)).append(';')
                        .append(csv(t.item)).append(';').append(t.qty).append(';')
                        .append(String.format(Locale.GERMANY, "%.2f", t.price)).append(';')
                        .append(String.format(Locale.GERMANY, "%.2f", t.price * t.qty)).append(';')
                        .append(p == null ? "" : String.format(Locale.GERMANY, "%.2f", p)).append(';')
                        .append(csv(t.note)).append('\n');
            }
            Files.writeString(f, sb.toString(), StandardCharsets.UTF_8);
            setStatus("Exportiert: config/julius_inc_export.csv (" + l.size() + " Buchungen)", C_GOOD);
        } catch (Exception e) {
            setStatus("Export fehlgeschlagen: " + e.getMessage(), C_BAD);
        }
    }

    private static String csv(String s) {
        if (s == null) return "";
        return "\"" + s.replace("\"", "\"\"").replace("\n", " ") + "\"";
    }

    // ------------------------------------------------------------------ Zeichnen

    private void txt(GuiGraphicsExtractor g, String s, int x, int y, int color) {
        g.text(this.font, s, x, y, color, false);
    }

    private String fit(String s, int maxW) {
        if (s == null) return "";
        if (this.font.width(s) <= maxW) return s;
        while (s.length() > 1 && this.font.width(s + "...") > maxW) s = s.substring(0, s.length() - 1);
        return s + "...";
    }

    private void drawFrame(GuiGraphicsExtractor g) {
        g.fill(px - 1, py - 1, px + pw + 1, py + ph + 1, C_GOLD);
        g.fill(px, py, px + pw, py + ph, C_BG);
        g.fill(px, py, px + pw, py + 26, C_PANEL);
        g.fill(px, py + 26, px + pw, py + 27, C_GOLD);

        Component name = Component.literal("JULIUS INC.").withStyle(ChatFormatting.BOLD);
        g.text(this.font, name, px + 8, py + 9, C_GOLD, false);
        int nx = px + 8 + this.font.width(name) + 4;
        txt(g, "— THE HUGO TRADING COMPANY", nx, py + 9, C_GOLD_L);
        String cash = "Kasse " + Fmt.money(st.cash);
        txt(g, cash, px + pw - 8 - this.font.width(cash), py + 9, st.cash >= 0 ? C_GOOD : C_BAD);
    }

    private void drawContent(GuiGraphicsExtractor g) {
        switch (tab) {
            case OVERVIEW -> drawOverview(g);
            case TRADE -> drawTrade(g);
            case HISTORY -> drawHistory(g);
            case STOCK -> drawStock(g);
            case PRICES -> drawPrices(g);
            case FEED -> drawFeed(g);
            case SETTINGS -> drawSettings(g);
        }
        if (!status.isEmpty()) txt(g, fit(status, pw - 20), px + 10, py + ph - 12, statusColor);
    }

    private void card(GuiGraphicsExtractor g, int x, int y, int w, int h, String label, String value, int vc) {
        g.fill(x, y, x + w, y + h, C_PANEL);
        g.fill(x, y, x + 2, y + h, C_GOLD);
        txt(g, fit(label, w - 10), x + 6, y + 5, C_MUTED);
        txt(g, fit(value, w - 10), x + 6, y + h - 13, vc);
    }

    private void drawOverview(GuiGraphicsExtractor g) {
        int cw = (pw - 20 - 18) / 4, ch = 34;
        int x0 = px + 10;
        String[] l1 = {"Startkapital", "Kassenbestand", "Lagerwert", "Gesamtvermögen"};
        String[] v1 = {Fmt.money(st.startCapital), Fmt.money(st.cash), Fmt.money(st.inventoryValue), Fmt.money(st.equity)};
        int[] c1 = {C_TEXT, st.cash >= 0 ? C_GOOD : C_BAD, C_TEXT, C_GOLD_L};
        String[] l2 = {"Realisierter Gewinn", "Einnahmen gesamt", "Ausgaben gesamt", "ROI seit Start"};
        String[] v2 = {Fmt.signedMoney(st.realized), Fmt.money(st.sold + st.income), Fmt.money(st.bought + st.expenses),
                Fmt.percent(st.roi)};
        int[] c2 = {st.realized >= 0 ? C_GOOD : C_BAD, C_TEXT, C_TEXT,
                Double.isNaN(st.roi) ? C_MUTED : (st.roi >= 0 ? C_GOOD : C_BAD)};
        for (int i = 0; i < 4; i++) {
            card(g, x0 + i * (cw + 6), cy, cw, ch, l1[i], v1[i], c1[i]);
            card(g, x0 + i * (cw + 6), cy + 40, cw, ch, l2[i], v2[i], c2[i]);
        }

        int chartTop = cy + 82;
        int chartBottom = py + ph - 26;
        int chartH = Math.max(46, chartBottom - chartTop);
        int cx0 = px + 10, cwid = pw - 20;
        g.fill(cx0, chartTop, cx0 + cwid, chartTop + chartH, C_PANEL);
        txt(g, "Tagesergebnis der letzten 14 Tage", cx0 + 6, chartTop + 3, C_GOLD_L);

        double max = 0, sum = 0;
        for (double d : st.daily) {
            max = Math.max(max, Math.abs(d));
            sum += d;
        }
        String sumTxt = "Summe " + Fmt.signedMoney(sum);
        txt(g, sumTxt, cx0 + cwid - 6 - this.font.width(sumTxt), chartTop + 3, sum >= 0 ? C_GOOD : C_BAD);

        int areaTop = chartTop + 15, areaBottom = chartTop + chartH - 11;
        int base = (areaTop + areaBottom) / 2;
        int half = Math.max(4, (areaBottom - areaTop) / 2);
        g.fill(cx0 + 4, base, cx0 + cwid - 4, base + 1, C_GOLD);
        int bw = (cwid - 20) / 14;
        LocalDate today = LocalDate.now();
        for (int i = 0; i < 14; i++) {
            int bx = cx0 + 10 + i * bw;
            double v = st.daily[i];
            if (max > 0 && v != 0) {
                int h = Math.max(1, (int) Math.round(Math.abs(v) / max * half));
                if (v > 0) g.fill(bx + 3, base - h, bx + bw - 3, base, C_GOOD);
                else g.fill(bx + 3, base + 1, bx + bw - 3, base + 1 + h, C_BAD);
            }
            String day = String.valueOf(today.minusDays(13 - i).getDayOfMonth());
            txt(g, day, bx + (bw - this.font.width(day)) / 2, chartTop + chartH - 10, C_MUTED);
        }
        if (max == 0) txt(g, "Noch keine Ergebnisse. Buche Käufe/Verkäufe im Tab Handel.", cx0 + 10, base - 12, C_MUTED);

        int quote = st.sells > 0 ? (int) Math.round(st.wins * 100.0 / st.sells) : 0;
        String info = "Käufe " + st.buys + "  |  Verkäufe " + st.sells + "  |  Trefferquote " + (st.sells > 0 ? quote + "%" : "-")
                + "  |  Bester Verkauf " + (st.sells > 0 ? Fmt.signedMoney(st.best) : "-");
        txt(g, fit(info, pw - 20), px + 10, py + ph - 22, C_MUTED);
        if (st.startCapital <= 0) {
            txt(g, "Tipp: Setze unter Optionen dein Startkapital.", px + 10, py + ph - 12, C_GOLD_L);
        }
    }

    private void drawTrade(GuiGraphicsExtractor g) {
        int lx = px + 10;
        txt(g, "Artikel", lx, cy + 6, C_GOLD_L);
        txt(g, "Menge", lx, cy + 30, C_GOLD_L);
        txt(g, "Stückpreis", lx, cy + 54, C_GOLD_L);
        txt(g, "Notiz", lx, cy + 78, C_GOLD_L);

        int y = cy + 128;
        g.fill(px + 10, y - 4, px + pw - 10, y + 26, C_PANEL);
        double price = Fmt.parse(fPrice);
        long qty = Fmt.parseQty(fQty);
        if (Double.isNaN(price) || qty < 1) {
            txt(g, "Vorschau: Menge und Stückpreis eingeben (z.B. 2 x 1,5m).", px + 16, y + 4, C_MUTED);
            return;
        }
        double total = price * qty;
        int half = pw / 2;
        txt(g, "Gesamt: " + Fmt.money(total), px + 16, y, C_TEXT);
        Calc.Holding h = st.holdings.get(Calc.key(fItem));
        if (h != null && h.qty > 0) {
            double gain = (price - h.avg()) * Math.min(qty, h.qty);
            txt(g, fit("Bestand " + h.qty + " zu Ø " + Fmt.money(h.avg()), half - 20), px + half, y, C_MUTED);
            txt(g, "Gewinn bei Verkauf: " + Fmt.signedMoney(gain), px + 16, y + 11, gain >= 0 ? C_GOOD : C_BAD);
        } else {
            txt(g, "Kein erfasster Bestand", px + half, y, C_MUTED);
        }
        txt(g, fit("Kasse nach Kauf " + Fmt.money(st.cash - total) + " / nach Verkauf " + Fmt.money(st.cash + total),
                half - 10), px + half, y + 11, C_MUTED);
    }

    private void drawHistory(GuiGraphicsExtractor g) {
        List<Data.Tx> list = historyList();
        int per = per(22, 38);
        int from = page * per, to = Math.min(list.size(), from + per);
        if (list.isEmpty()) txt(g, "Noch keine Buchungen. Leg im Tab Handel los.", px + 12, cy + 8, C_MUTED);
        for (int i = from; i < to; i++) {
            Data.Tx t = list.get(i);
            int y = cy + (i - from) * 22;
            g.fill(px + 10, y, px + pw - 40, y + 20, (i % 2 == 0) ? C_PANEL : C_PANEL2);
            String l1 = Fmt.date(t.time) + "  " + label(t.type) + "  " + t.item + "  " + t.qty + " x "
                    + Fmt.money(t.price) + " = " + Fmt.money(t.qty * t.price);
            txt(g, fit(l1, pw - 64), px + 14, y + 2, typeColor(t.type));
            Double p = st.profitByTx.get(t.id);
            String l2 = (p != null ? "Ergebnis " + Fmt.signedMoney(p) : "");
            if (!t.note.isEmpty()) l2 += (l2.isEmpty() ? "" : "  |  ") + t.note;
            int c2 = p != null ? (p >= 0 ? C_GOOD : C_BAD) : C_MUTED;
            txt(g, fit(l2, pw - 64), px + 14, y + 11, c2);
        }
        pageLabel(g, list.size(), per);
    }

    private List<Calc.Holding> holdingsSorted() {
        List<Calc.Holding> l = new ArrayList<>();
        for (Calc.Holding h : st.holdings.values()) if (h.qty > 0) l.add(h);
        l.sort(Comparator.comparingDouble((Calc.Holding h) -> -h.cost));
        return l;
    }

    private int invSpawners() {
        if (this.minecraft == null || this.minecraft.player == null) return 0;
        Inventory inv = this.minecraft.player.getInventory();
        int n = 0;
        for (int i = 0; i < inv.getContainerSize(); i++) {
            ItemStack s = inv.getItem(i);
            if (!s.isEmpty() && s.is(Items.SPAWNER)) n += s.getCount();
        }
        return n;
    }

    private void drawStock(GuiGraphicsExtractor g) {
        long booked = 0;
        for (Calc.Holding h : st.holdings.values()) {
            if (h.qty > 0 && h.name.toLowerCase(Locale.ROOT).contains("spawner")) booked += h.qty;
        }
        long inv = invSpawners();
        String rec = "Spawner im Inventar: " + inv + "  |  gebucht: " + booked
                + (inv == booked ? "  (stimmt)" : "  (Differenz " + (inv - booked) + ")");
        txt(g, fit(rec, pw - 20), px + 10, cy, inv == booked ? C_GOOD : C_GOLD_L);

        int y0 = cy + 14;
        int x1 = px + 10, x2 = px + (int) (pw * 0.34), x3 = px + (int) (pw * 0.44), x4 = px + (int) (pw * 0.61),
                x5 = px + (int) (pw * 0.78);
        g.fill(px + 10, y0 - 2, px + pw - 10, y0 + 10, C_PANEL);
        txt(g, "Artikel", x1 + 2, y0, C_GOLD_L);
        txt(g, "Menge", x2, y0, C_GOLD_L);
        txt(g, "Ø Einkauf", x3, y0, C_GOLD_L);
        txt(g, "Marktwert", x4, y0, C_GOLD_L);
        txt(g, "Gewinn/Verl.", x5, y0, C_GOLD_L);

        List<Calc.Holding> list = holdingsSorted();
        int per = per(13, 52);
        int from = page * per, to = Math.min(list.size(), from + per);
        if (list.isEmpty()) txt(g, "Kein Bestand. Käufe erscheinen hier automatisch.", px + 12, y0 + 16, C_MUTED);
        for (int i = from; i < to; i++) {
            Calc.Holding h = list.get(i);
            int y = y0 + 14 + (i - from) * 13;
            Data.Price p = Data.price(h.name);
            double unit = (p != null && p.sell > 0) ? p.sell : h.avg();
            double value = unit * h.qty;
            double gl = value - h.cost;
            txt(g, fit(h.name, x2 - x1 - 8), x1 + 2, y, C_TEXT);
            txt(g, String.valueOf(h.qty), x2, y, C_TEXT);
            txt(g, Fmt.money(h.avg()), x3, y, C_MUTED);
            txt(g, Fmt.money(value) + (p != null && p.sell > 0 ? "" : "*"), x4, y, C_TEXT);
            txt(g, Fmt.signedMoney(gl), x5, y, gl >= 0 ? C_GOOD : C_BAD);
        }
        txt(g, "* ohne Verkaufspreis in der Preisliste: bewertet zum Einkaufspreis", px + 10, py + ph - 24,
                C_MUTED);
        pageLabel(g, list.size(), per);
    }

    private void drawPrices(GuiGraphicsExtractor g) {
        int y0 = cy + 28;
        g.fill(px + 10, y0 - 2, px + pw - 40, y0 + 10, C_PANEL);
        int x1 = px + 14, x2 = px + (int) (pw * 0.34), x3 = px + (int) (pw * 0.50), x4 = px + (int) (pw * 0.66),
                x5 = px + (int) (pw * 0.78);
        txt(g, "Artikel", x1, y0, C_GOLD_L);
        txt(g, "Kauf", x2, y0, C_GOLD_L);
        txt(g, "Verkauf", x3, y0, C_GOLD_L);
        txt(g, "Marge", x4, y0, C_GOLD_L);
        txt(g, "Stand", x5, y0, C_GOLD_L);

        int per = per(22, 78);
        int total = Data.root.prices.size();
        int from = page * per, to = Math.min(total, from + per);
        if (total == 0) {
            txt(g, "Noch keine Preise. Trage die Preise vom Hugo SMP selbst ein.", px + 12, y0 + 16, C_MUTED);
        }
        for (int i = from; i < to; i++) {
            Data.Price p = Data.root.prices.get(i);
            int y = cy + 40 + (i - from) * 22;
            g.fill(px + 10, y, px + pw - 40, y + 20, (i % 2 == 0) ? C_PANEL : C_PANEL2);
            txt(g, fit(p.item, x2 - x1 - 6), x1, y + 6, C_TEXT);
            txt(g, p.buy > 0 ? Fmt.money(p.buy) : "-", x2, y + 6, C_TEXT);
            txt(g, p.sell > 0 ? Fmt.money(p.sell) : "-", x3, y + 6, C_TEXT);
            if (p.buy > 0 && p.sell > 0) {
                double m = (p.sell - p.buy) / p.buy * 100.0;
                txt(g, Fmt.percent(m), x4, y + 6, m >= 0 ? C_GOOD : C_BAD);
            } else {
                txt(g, "-", x4, y + 6, C_MUTED);
            }
            txt(g, Fmt.date(p.time).substring(0, 8), x5, y + 6, C_MUTED);
        }
        pageLabel(g, total, per);
    }

    private void drawFeed(GuiGraphicsExtractor g) {
        txt(g, fit("Chat-Zeilen mit deinen Stichwörtern (Optionen). Preise trägst du selbst unter Preise ein.", pw - 20),
                px + 10, cy, C_MUTED);
        List<String> l = new ArrayList<>(Data.root.feed);
        Collections.reverse(l);
        int per = per(11, 52);
        int from = page * per, to = Math.min(l.size(), from + per);
        if (l.isEmpty()) {
            txt(g, Data.root.feedEnabled ? "Noch keine passenden Chat-Zeilen." : "Feed ist ausgeschaltet (Optionen).",
                    px + 12, cy + 18, C_MUTED);
        }
        for (int i = from; i < to; i++) {
            txt(g, fit(l.get(i), pw - 24), px + 12, cy + 14 + (i - from) * 11, (i % 2 == 0) ? C_TEXT : C_GOLD_L);
        }
        pageLabel(g, l.size(), per);
    }

    private void drawSettings(GuiGraphicsExtractor g) {
        txt(g, "Startkapital", px + 10, cy + 6, C_GOLD_L);
        txt(g, "Feed-Stichwörter", px + 10, cy + 34, C_GOLD_L);
        txt(g, "Daten: config/julius_inc.json", px + 170, cy + 62, C_MUTED);
        txt(g, "Export: config/julius_inc_export.csv", px + 170, cy + 74, C_MUTED);
        txt(g, "Dashboard-Taste ändern: Optionen > Steuerung > Tastenbelegung", px + 170, cy + 92, C_MUTED);
        txt(g, "Zahlen: 1500  1,5k  2m  1b   (Tausenderpunkte ok: 1.500)", px + 170, cy + 104, C_MUTED);
    }

    // ------------------------------------------------------------------ Helfer

    private static String label(Data.Type t) {
        return switch (t) {
            case BUY -> "KAUF";
            case SELL -> "VERKAUF";
            case EXPENSE -> "AUSGABE";
            case INCOME -> "EINNAHME";
        };
    }

    private static int typeColor(Data.Type t) {
        return switch (t) {
            case BUY -> C_GOLD_L;
            case SELL -> C_GOOD;
            case EXPENSE -> C_BAD;
            case INCOME -> C_TEXT;
        };
    }
}
