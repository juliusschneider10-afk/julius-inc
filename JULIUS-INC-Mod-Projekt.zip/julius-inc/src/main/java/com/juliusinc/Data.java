package com.juliusinc;

import java.io.IOException;
import java.io.Reader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.List;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import net.fabricmc.loader.api.FabricLoader;

/** Datenmodell + dauerhafte lokale Speicherung (config/julius_inc.json). */
public final class Data {
    public enum Type { BUY, SELL, EXPENSE, INCOME }

    public static final class Tx {
        public long id;
        public long time;
        public Type type;
        public String item = "";
        public long qty = 1;
        public double price;
        public String note = "";
    }

    public static final class Price {
        public String item = "";
        public double buy;
        public double sell;
        public long time;
    }

    public static final class Root {
        public double startCapital = 0;
        public long nextId = 1;
        public List<Tx> tx = new ArrayList<>();
        public List<Price> prices = new ArrayList<>();
        public List<String> feed = new ArrayList<>();
        public String keywords = "spawner,kaufe,verkaufe,verkauf,shop,auktion";
        public boolean feedEnabled = true;
    }

    public static Root root = new Root();
    public static boolean dirty = false;

    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

    private Data() {}

    public static Path file() {
        return FabricLoader.getInstance().getConfigDir().resolve("julius_inc.json");
    }

    public static void load() {
        Path f = file();
        if (Files.exists(f)) {
            try (Reader r = Files.newBufferedReader(f, StandardCharsets.UTF_8)) {
                Root loaded = GSON.fromJson(r, Root.class);
                if (loaded != null) root = loaded;
            } catch (Exception e) {
                JuliusIncClient.LOGGER.error("JULIUS INC.: Datei konnte nicht gelesen werden, lege Sicherung an", e);
                try {
                    Files.copy(f, f.resolveSibling("julius_inc.json.defekt-" + System.currentTimeMillis()),
                            StandardCopyOption.REPLACE_EXISTING);
                } catch (IOException ignored) {
                }
            }
        }
        if (root.tx == null) root.tx = new ArrayList<>();
        if (root.prices == null) root.prices = new ArrayList<>();
        if (root.feed == null) root.feed = new ArrayList<>();
        if (root.keywords == null) root.keywords = "";
        root.tx.removeIf(t -> t == null || t.type == null);
        for (Tx t : root.tx) {
            if (t.item == null) t.item = "";
            if (t.note == null) t.note = "";
            if (t.id >= root.nextId) root.nextId = t.id + 1;
        }
    }

    public static synchronized void save() {
        try {
            Path f = file();
            Files.createDirectories(f.getParent());
            Path tmp = f.resolveSibling("julius_inc.json.tmp");
            Files.writeString(tmp, GSON.toJson(root), StandardCharsets.UTF_8);
            try {
                Files.move(tmp, f, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
            } catch (IOException atomicFail) {
                Files.move(tmp, f, StandardCopyOption.REPLACE_EXISTING);
            }
            dirty = false;
        } catch (IOException e) {
            JuliusIncClient.LOGGER.error("JULIUS INC.: Speichern fehlgeschlagen", e);
        }
    }

    public static long nextId() {
        return root.nextId++;
    }

    public static Price price(String item) {
        if (item == null) return null;
        String k = item.trim();
        for (Price p : root.prices) {
            if (p.item != null && p.item.trim().equalsIgnoreCase(k)) return p;
        }
        return null;
    }
}
