package com.juliusinc;

import java.math.BigDecimal;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

/** Formatierung und Eingabe-Parser (unterstuetzt 1k, 2,5m, 1b, 1.500, 1500,50). */
public final class Fmt {
    private static final DateTimeFormatter DATE = DateTimeFormatter.ofPattern("dd.MM.yy HH:mm");
    private static final DateTimeFormatter TIME = DateTimeFormatter.ofPattern("HH:mm");

    private Fmt() {}

    public static String full(double v) {
        return String.format(Locale.GERMANY, "%,.2f", v);
    }

    public static String money(double v) {
        double a = Math.abs(v);
        String s;
        if (a >= 1e9) s = String.format(Locale.GERMANY, "%.2f B", a / 1e9);
        else if (a >= 1e6) s = String.format(Locale.GERMANY, "%.2f M", a / 1e6);
        else if (a >= 1e4) s = String.format(Locale.GERMANY, "%.1f K", a / 1e3);
        else s = String.format(Locale.GERMANY, "%,.2f", a);
        return (v < 0 ? "-" : "") + "$" + s;
    }

    public static String signedMoney(double v) {
        return (v > 0 ? "+" : "") + money(v);
    }

    public static String percent(double p) {
        if (Double.isNaN(p) || Double.isInfinite(p)) return "-";
        return String.format(Locale.GERMANY, "%+.1f%%", p);
    }

    public static String date(long ms) {
        return LocalDateTime.ofInstant(Instant.ofEpochMilli(ms), ZoneId.systemDefault()).format(DATE);
    }

    public static String time(long ms) {
        return LocalDateTime.ofInstant(Instant.ofEpochMilli(ms), ZoneId.systemDefault()).format(TIME);
    }

    /** Zahl fuer Eingabefelder (Komma als Dezimaltrenner, keine Tausenderpunkte). */
    public static String plain(double v) {
        return BigDecimal.valueOf(v).stripTrailingZeros().toPlainString().replace('.', ',');
    }

    /** Liefert NaN bei ungueltiger Eingabe. */
    public static double parse(String s) {
        if (s == null) return Double.NaN;
        String t = s.trim().toLowerCase(Locale.ROOT)
                .replace(" ", "").replace("_", "").replace("$", "").replace("€", "");
        if (t.isEmpty()) return Double.NaN;
        double mult = 1;
        char last = t.charAt(t.length() - 1);
        if (last == 'k') mult = 1e3;
        else if (last == 'm') mult = 1e6;
        else if (last == 'b') mult = 1e9;
        if (mult != 1) t = t.substring(0, t.length() - 1);
        if (t.isEmpty()) return Double.NaN;
        if (t.matches("\\d{1,3}(\\.\\d{3})+(,\\d+)?")) {
            t = t.replace(".", "").replace(',', '.');
        } else {
            t = t.replace(',', '.');
        }
        try {
            double v = Double.parseDouble(t) * mult;
            if (Double.isNaN(v) || Double.isInfinite(v)) return Double.NaN;
            return v;
        } catch (NumberFormatException e) {
            return Double.NaN;
        }
    }

    /** Ganzzahlige Menge >= 1, sonst -1. */
    public static long parseQty(String s) {
        double d = parse(s);
        if (Double.isNaN(d) || d < 1 || d > 1e9 || d != Math.floor(d)) return -1;
        return (long) d;
    }
}
