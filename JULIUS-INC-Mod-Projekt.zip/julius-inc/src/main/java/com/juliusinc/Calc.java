package com.juliusinc;

import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/** Berechnet Bestand (gewichteter Durchschnittspreis), Gewinne und Kennzahlen aus allen Buchungen. */
public final class Calc {
    public static final class Holding {
        public final String name;
        public long qty;
        public double cost;

        Holding(String name) {
            this.name = name;
        }

        public double avg() {
            return qty > 0 ? cost / qty : 0;
        }
    }

    public static final class Stats {
        public double startCapital, cash, bought, sold, expenses, income, realized;
        public double inventoryCost, inventoryValue, equity, roi;
        public int buys, sells, wins;
        public double best = 0, worst = 0;
        public final Map<String, Holding> holdings = new LinkedHashMap<>();
        public final Map<Long, Double> profitByTx = new HashMap<>();
        /** Tagesergebnis der letzten 14 Tage, Index 13 = heute. */
        public final double[] daily = new double[14];
    }

    private Calc() {}

    public static String key(String item) {
        return item == null ? "" : item.trim().toLowerCase(Locale.ROOT);
    }

    public static Stats compute() {
        Stats s = new Stats();
        s.startCapital = Data.root.startCapital;
        List<Data.Tx> list = new ArrayList<>(Data.root.tx);
        list.sort(Comparator.comparingLong((Data.Tx t) -> t.time).thenComparingLong(t -> t.id));
        LocalDate today = LocalDate.now();
        boolean firstSell = true;

        for (Data.Tx t : list) {
            if (t.type == null) continue;
            double total = t.qty * t.price;
            long dayIdx = ChronoUnit.DAYS.between(
                    Instant.ofEpochMilli(t.time).atZone(ZoneId.systemDefault()).toLocalDate(), today);
            double dayDelta = 0;

            switch (t.type) {
                case BUY -> {
                    Holding h = hold(s, t.item);
                    h.qty += t.qty;
                    h.cost += total;
                    s.bought += total;
                    s.buys++;
                }
                case SELL -> {
                    Holding h = hold(s, t.item);
                    double avg = h.avg();
                    long matched = Math.min(t.qty, h.qty);
                    double costBasis = avg * matched;
                    double profit = total - costBasis;
                    h.qty -= matched;
                    h.cost -= costBasis;
                    if (h.qty <= 0) {
                        h.qty = 0;
                        h.cost = 0;
                    }
                    s.sold += total;
                    s.sells++;
                    s.realized += profit;
                    s.profitByTx.put(t.id, profit);
                    if (profit > 0) s.wins++;
                    if (firstSell) {
                        s.best = profit;
                        s.worst = profit;
                        firstSell = false;
                    } else {
                        s.best = Math.max(s.best, profit);
                        s.worst = Math.min(s.worst, profit);
                    }
                    dayDelta = profit;
                }
                case EXPENSE -> {
                    s.expenses += total;
                    dayDelta = -total;
                }
                case INCOME -> {
                    s.income += total;
                    dayDelta = total;
                }
            }
            if (dayIdx >= 0 && dayIdx < 14) s.daily[(int) (13 - dayIdx)] += dayDelta;
        }

        s.cash = s.startCapital - s.bought + s.sold - s.expenses + s.income;
        for (Holding h : s.holdings.values()) {
            if (h.qty <= 0) continue;
            s.inventoryCost += h.cost;
            Data.Price p = Data.price(h.name);
            double unit = (p != null && p.sell > 0) ? p.sell : h.avg();
            s.inventoryValue += unit * h.qty;
        }
        s.equity = s.cash + s.inventoryValue;
        s.roi = s.startCapital > 0 ? (s.equity - s.startCapital) / s.startCapital * 100.0 : Double.NaN;
        return s;
    }

    private static Holding hold(Stats s, String item) {
        String name = item == null ? "" : item.trim();
        return s.holdings.computeIfAbsent(key(name), k -> new Holding(name));
    }
}
