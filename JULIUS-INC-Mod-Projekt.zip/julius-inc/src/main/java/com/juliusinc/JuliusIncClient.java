package com.juliusinc;

import org.lwjgl.glfw.GLFW;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.mojang.blaze3d.platform.InputConstants;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper;
import net.fabricmc.fabric.api.client.message.v1.ClientReceiveMessageEvents;
import net.minecraft.client.KeyMapping;
import net.minecraft.resources.Identifier;

public class JuliusIncClient implements ClientModInitializer {
    public static final String MOD_ID = "julius_inc";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    private static KeyMapping openKey;
    private static int ticks = 0;

    @Override
    public void onInitializeClient() {
        Data.load();

        KeyMapping.Category category = KeyMapping.Category.register(
                Identifier.fromNamespaceAndPath(MOD_ID, "main"));
        openKey = KeyMappingHelper.registerKeyMapping(new KeyMapping(
                "key.julius_inc.open", InputConstants.Type.KEYSYM, GLFW.GLFW_KEY_J, category));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openKey.consumeClick()) {
                client.setScreen(new DashboardScreen());
            }
            if (++ticks % 200 == 0 && Data.dirty) Data.save();
        });

        ClientReceiveMessageEvents.GAME.register((message, overlay) -> {
            if (!overlay) Feed.add(message.getString());
        });
        ClientReceiveMessageEvents.CHAT.register((message, signed, sender, params, time) ->
                Feed.add(message.getString()));

        ClientLifecycleEvents.CLIENT_STOPPING.register(client -> Data.save());

        LOGGER.info("JULIUS INC. - THE HUGO TRADING COMPANY geladen. Dashboard: Taste J (aenderbar).");
    }
}
